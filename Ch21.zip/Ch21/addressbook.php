<?php
    header("Content-Type: text/plain");
?>
[
    {
        "name": "Nicholas C. Zakas",
        "email": "nicholas@some-domain-name.com"
    },
    {
        "name": "Jim Smith",
        "email": "jimsmith@some-domain-name.com"
    },    {
        "name": "Michael Jones",
        "email": "mj@some-domain-name.com"
    }
]